<?php


namespace App\Services;



interface IService
{
    /* public function destroy($id);

    public function show($id);

    public function store($data);

    public function update($id, $data);

    public function get(); */
}
